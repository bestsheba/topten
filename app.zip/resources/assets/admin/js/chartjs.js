import Chart from 'chart.js/auto';
window.Chart = Chart;
