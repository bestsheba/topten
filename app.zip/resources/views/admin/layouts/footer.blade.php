<footer class="main-footer text-center">
    <strong>Copyright &copy; {{ date('Y') }} ○○○
        Developed By <a href="https://bestsheba.com/">Best Sheba</a>.</strong>
</footer>
