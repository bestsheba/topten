<?php

namespace App\Helpers;

class LandingPageConfig
{
    public static function getDefaultConfig(): array
    {
        return [
            'common' => [
                'hero_title' => 'কম্বো প্যাকেজ থাকছে এখন!',
                'hero_subtitle' => '১৮ রকমের ভিন্ন ভিন্ন স্বাদের',
                'hero_highlight' => '২১০ পিস আচার',
                'offer_percent' => '35%',
                'phone_1' => '0160616xxxx',
                'phone_2' => '01864444xxxx',
                'primary_bg_color' => '#dc2626',
                'primary_text_color' => '#ffffff',
                'secondary_bg_color' => '#fbbf24',
                'secondary_text_color' => '#000000',
            ],
            'sections' => [
                [
                    'id' => 'hero',
                    'name' => 'Hero Banner',
                    'type' => 'hero',
                    'enabled' => true,
                    'order' => 1,
                    'data' => [
                        'background_image' => 'https://placehold.co/1200x600.png?text=1200x600',
                        'cta_text' => 'অর্ডার করতে চাই',
                        'cta_link' => '#',
                        'badge_text' => '⚡ এক্সক্লুসিভ অফার চলছে',
                    ],
                ],
                [
                    'id' => 'packages',
                    'name' => 'প্যাকেজ অপশন',
                    'type' => 'packages',
                    'enabled' => true,
                    'order' => 2,
                    'data' => [
                        'title' => '🎁 কম্বো প্যাকেজে থাকছেঃ',
                        'subtitle' => 'সব ধরনের আচারের স্বাদ একসাথে পান',
                        'packages' => [
                            [
                                'product_id' => null,
                                'name' => 'আম ১০ পিস',
                                'image' => 'https://placehold.co/400x400.png?text=400x400',
                                'badge' => '⭐ সবচেয়ে জনপ্রিয়',
                            ],
                            [
                                'product_id' => null,
                                'name' => 'ইন্ডিরনেট ১০ পিস',
                                'image' => 'https://placehold.co/400x400.png?text=400x400',
                                'badge' => '🔥 অত্যন্ত মসলাদার',
                            ],
                            [
                                'product_id' => null,
                                'name' => 'চালতা ১০ পিস',
                                'image' => 'https://placehold.co/400x400.png?text=400x400',
                                'badge' => '✨ তাজা এবং খাস্তা',
                            ],
                        ],
                    ],
                ],
                [
                    'id' => 'why_order',
                    'name' => 'কেন অর্ডার করবেন',
                    'type' => 'features',
                    'enabled' => true,
                    'order' => 3,
                    'data' => [
                        'title' => '✨ কেন আমাদের কাছ থেকে অর্ডার করবেন?',
                        'features' => [
                            [
                                'icon' => '💰',
                                'title' => 'কোনো এডভান্স নেই!',
                                'description' => 'অর্ডার কনফার্ম করতে ১ টাকাও দিতে হবে না।',
                                'color' => 'from-red-600 to-red-700',
                            ],
                            [
                                'icon' => '✔️',
                                'title' => 'পণ্য চেক করে পরিশোধ করুন',
                                'description' => 'পণ্য হাতে পাওয়ার পরে চেক করে, টেস্ট করে তারপর মূল্য দিন।',
                                'color' => 'from-orange-600 to-orange-700',
                            ],
                            [
                                'icon' => '↩️',
                                'title' => 'সহজ রিটার্ন পলিসি',
                                'description' => 'ভালো না লাগলে সাথে সাথে রিটার্ন করে দিতে পারবেন।',
                                'color' => 'from-yellow-600 to-yellow-700',
                            ],
                            [
                                'icon' => '🚀',
                                'title' => 'দ্রুত হোম ডেলিভারি',
                                'description' => 'সারা বাংলাদেশে সিটি ফাস্ট কুরিয়ারের মাধ্যমে দ্রুত ডেলিভারি।',
                                'color' => 'from-green-600 to-green-700',
                            ],
                            [
                                'icon' => '⏰',
                                'title' => '২৪/৭ কাস্টমার সাপোর্ট',
                                'description' => 'যেকোনো সময় আমাদের সাথে যোগাযোগ করতে পারবেন।',
                                'color' => 'from-blue-600 to-blue-700',
                            ],
                            [
                                'icon' => '💳',
                                'title' => 'ক্যাশ অন ডেলিভারি',
                                'description' => 'সারা বাংলাদেশে ক্যাশ অন ডেলিভারি সুবিধা উপলব্ধ।',
                                'color' => 'from-purple-600 to-purple-700',
                            ],
                        ],
                    ],
                ],
                [
                    'id' => 'testimonials',
                    'name' => 'কাস্টমার রিভিউ',
                    'type' => 'testimonials',
                    'enabled' => true,
                    'order' => 4,
                    'data' => [
                        'title' => '⭐ আমাদের সন্তুষ্ট গ্রাহকরা',
                        'subtitle' => 'হাজারো খুশি গ্রাহক আমাদের বিশ্বাস করেন',
                        'testimonials' => [
                            ['image' => 'https://placehold.co/400x400.png?text=400x400', 'rating' => '⭐⭐⭐⭐⭐', 'text' => 'খুব ভালো পণ্য পেয়েছি'],
                            ['image' => 'https://placehold.co/400x400.png?text=400x400', 'rating' => '⭐⭐⭐⭐⭐', 'text' => 'দ্রুত ডেলিভারি পেয়েছি'],
                            ['image' => 'https://placehold.co/400x400.png?text=400x400', 'rating' => '⭐⭐⭐⭐⭐', 'text' => 'সাশ্রয়ী মূল্যে মানসম্মত'],
                            ['image' => 'https://placehold.co/400x400.png?text=400x400', 'rating' => '⭐⭐⭐⭐⭐', 'text' => 'সব স্বাদের আচার পেয়েছি'],
                            ['image' => 'https://placehold.co/400x400.png?text=400x400', 'rating' => '⭐⭐⭐⭐⭐', 'text' => 'বিশ্বস্ত ব্র্যান্ড'],
                            ['image' => 'https://placehold.co/400x400.png?text=400x400', 'rating' => '⭐⭐⭐⭐⭐', 'text' => 'পরিবারের সবার পছন্দ'],
                        ],
                    ],
                ],
                [
                    'id' => 'checkout',
                    'name' => 'চেকআউট ফর্ম',
                    'type' => 'checkout',
                    'enabled' => true,
                    'order' => 5,
                    'data' => [
                        'title' => '📝 অর্ডার করতে নিচের ফর্মটি পূরণ করুন',
                        'product_name' => 'কাঁচা প্যাকেজ (২১০ পিস)',
                        'product_price' => '1499.00',
                        'total_price' => '1499.00',
                        'delivery_charge' => 'বিনামূল্যে ✅',
                    ],
                ],
            ],
        ];
    }

    public static function getSectionById(array $config, string $id)
    {
        $sections = $config['sections'] ?? [];
        foreach ($sections as $section) {
            if ($section['id'] === $id) {
                return $section;
            }
        }
        return null;
    }

    public static function getEnabledSections(array $config): array
    {
        $sections = $config['sections'] ?? [];
        return array_filter($sections, fn($s) => $s['enabled'] ?? false);
    }
}
