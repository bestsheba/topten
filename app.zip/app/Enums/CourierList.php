<?php

namespace App\Enums;

enum CourierList: string
{
    case PATHAO = 'Pathao';
    case STEADFAST = 'Steadfast';
}
