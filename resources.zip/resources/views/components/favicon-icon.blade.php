<link rel="shortcut icon" href="{{ $settings?->website_favicon_path }}">
