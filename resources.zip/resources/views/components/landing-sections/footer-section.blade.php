<!-- Footer -->
<footer class="bg-black text-white py-8 px-4 text-center">
    <p class="text-gray-300 mb-4">© 2024 Combo Landing Page. সকল অধিকার সংরক্ষিত।</p>
    <div class="flex justify-center gap-6">
        <a href="#" class="text-gray-400 hover:text-white transition">গোপনীয়তা নীতি</a>
        <a href="#" class="text-gray-400 hover:text-white transition">সেবার শর্তাবলী</a>
    </div>
</footer>
