<div class="col-span-full md:col-span-3">
    @include('frontend.pages.user.sidebar-menu')
</div>
